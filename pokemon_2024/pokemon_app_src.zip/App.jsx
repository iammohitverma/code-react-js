import PokemonApi from "./PokemonApi";
export const App = () => {


  return (
    <>
      <PokemonApi />
    </>
  );
}